package db;

import java.sql.*;

public class db {
	
	public static Connection getConnection(){
		Connection conn=null;
		try{
			String driver="com.mysql.jdbc.Driver";
			String url="jdbc:mysql://localhost:3306/onlinePhotoAlbum?useUnicode=true&characterEncoding=UTF-8";
			String username="root";
			String password="";
			Class.forName(driver);
			conn=DriverManager.getConnection(url,username,password);
		}catch(Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
	}
	
	public static void closeConnection(Connection conn){
		try{
			conn.close();
		}catch(Exception e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
