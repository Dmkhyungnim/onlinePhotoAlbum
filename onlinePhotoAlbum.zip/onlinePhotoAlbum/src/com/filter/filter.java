package com.filter;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class filter implements Filter{
    public void init(FilterConfig arg0) throws ServletException{}
    public void destroy(){}
    public void doFilter(ServletRequest request,ServletResponse response, FilterChain chain)
	throws IOException,ServletException{
        HttpServletRequest httprequest = (HttpServletRequest)request;
        HttpServletResponse httpresponse = (HttpServletResponse)response;
        HttpSession session = httprequest.getSession();
        if((session.getAttribute("username")!=null&&session.getAttribute("username")!="")
        		||(session.getAttribute("adid")!=null&&session.getAttribute("adid")!="")){   
        	//判断session中是否含有用户名，如果有继续执行
            chain.doFilter(request,response);
        }
        else{
           httpresponse.sendRedirect(httprequest.getContextPath()+"/photoAlbum/login.jsp");
        }
    }
}
